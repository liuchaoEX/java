package planeWar;

import java.awt.*;

public class SimpleBullet extends AbstractBullet{

    //构造方法，进行初始化
    public SimpleBullet(int x,int y){
        this.x = x;
        this.y = y;
        image = Toolkit.getDefaultToolkit().getImage("Images/bullet.png");
        this.width = image.getWidth(null);
        this.height = image.getHeight(null);
        this.hurtValue = 1;
        this.step = 3;
    }
    @Override
    public void move() {
        this.y = this.y - this.step;
    }

    @Override
    public void hurt() {

    }

    @Override
    public void paint(Graphics g) {
        g.drawImage(image,x,y,null);
    }
}
