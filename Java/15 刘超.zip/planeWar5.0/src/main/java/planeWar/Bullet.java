package planeWar;

public interface Bullet extends Display{
    void move();

    void hurt();

}
