package planeWar;

import java.awt.*;
import java.util.LinkedList;

public class PlayerPlane implements Display{
    //定义数据
    int x, y;
    int width, height;
    Image image;
    int lifeValue;
    int speed;
    int fireSort;
    //添加一个开火状态
    boolean isFire = true;
    //为玩家飞机加上子弹集合
    LinkedList<AbstractBullet> bulletList = new LinkedList<AbstractBullet>();

    //构造方法进行初始化
    public PlayerPlane(){
        this.x = 200;
        this.y = 200;
        this.image = Toolkit.getDefaultToolkit().getImage("Images/myPlane.png");
        this.width = 80;
        this.height = 80;
    }

    public void init(){
        this.x = 200;
        this.y = 200;
    }

    //定义方法
    public void move() {

    }
    public void fire() {

    }
    public void eatTools() {

    }
    public void paint(Graphics g) {
        g.drawImage(image,x,y,null);
    }
}
