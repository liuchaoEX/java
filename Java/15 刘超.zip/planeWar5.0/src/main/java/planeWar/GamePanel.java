package planeWar;

import javax.swing.*;
import java.awt.*;
import java.text.CollationElementIterator;
import java.util.LinkedList;

public class GamePanel extends JPanel{
    LinkedList<Display> disList;
    PlayerPlane playerPlane;
    int width, height;
    Image bgImage;
    //背景图片坐标
    int bgX,bgY;
    //背景图片的速度
    int bgSpeed;

    //初始化游戏面板
    public GamePanel() {
        this.width = 600;
        this.height =800;
        this.bgSpeed=2;
        bgImage = Toolkit.getDefaultToolkit().getImage("Images/bgImg.jpg");
        this.setBackground(Color.pink);//游戏面板的背景颜色
        this.setSize(500,500);
        //提供给自适应窗口的大小
        this.setPreferredSize(new Dimension(this.width,this.height));
    }

    //让游戏面板的背景图片移动
    public void bgMove(){
        this.bgY += this.bgSpeed;
        if (this.bgY >= this.height)
            this.bgY = 0;
    }

    //重写一个从父类继承的方法paint，这个方法负责面板绘制、
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        //g.drawOval(0,0,width,height);
        //画第一张图片
        g.drawImage(bgImage,bgX,bgY-this.height,width,height,this);
        //画第二张图片
        g.drawImage(bgImage,bgX,bgY,width,height,this);
        //绘制玩家飞机
//        this.playerPlane.paint(g);
        //被显示列表的所有元素绘制出来
        if (this.disList.size() != 0) {
            for (int i = 0; i < this.disList.size(); i++) {
                this.disList.get(i).paint(g);
            }
        }
        //如果游戏暂停，游戏界面提示”游戏暂停，按空格继续！“
        //设置画笔
        g.setColor(Color.WHITE);
        g.setFont(new Font("",Font.BOLD,30));
        g.drawString("你的成绩："+Control.gameScore,400,50);
        if (Control.gameState == Control.PAUSE){
            g.drawString("游戏暂停，按空格继续！",100,300);
        }
        //如果游戏结束，游戏界面提示“游戏结束，按空格再来一局！”
        else if (Control.gameState == Control.OVER) {
            g.drawString("游戏结束，按空格再来一局！",100,300);
        }
    }
}
