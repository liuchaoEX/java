package planeWar;

import java.awt.*;
import java.util.Random;

public class Enemy1 extends AbstractEnemy{
    //构造方法的实现
    public Enemy1(){
        this.image = Toolkit.getDefaultToolkit().getImage("Images/enemy1.png");
        this.width = image.getWidth(null);
        this.height = image.getHeight(null);
        this.x = new Random().nextInt(600 - this.width/2);//随机横坐标
        this.y = -this.height;
        this.lifeValue = 2;
        this.hurtValue = 1;
    }
    @Override
    public void paint(Graphics g) {
        g.drawImage(image,this.x,this.y,null);
    }

    @Override
    public void move() {
        y += 3;
    }
}
