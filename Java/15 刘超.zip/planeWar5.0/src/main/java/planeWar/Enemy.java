package planeWar;

public interface Enemy extends Display{
    void move();

}
