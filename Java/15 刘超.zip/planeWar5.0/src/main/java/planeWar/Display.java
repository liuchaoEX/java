package planeWar;

import java.awt.*;

public interface Display {
    //一个抽象的方法，实现绘制的功能
    void paint(Graphics g);
}
