package planeWar;

import java.awt.*;

//定义一个抽象类，使得子弹列表中的所有子弹利用这种类型可以方便地调用所有子弹的坐标等信息
public abstract class AbstractBullet implements Bullet{
    int x,y;
    int width,height;
    Image image;
    int hurtValue;
    int step;
}
